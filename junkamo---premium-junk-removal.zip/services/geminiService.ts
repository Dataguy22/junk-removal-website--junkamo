
import { GoogleGenAI, Type } from "@google/genai";
import { QuoteResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getSmartEstimate(description: string): Promise<QuoteResult> {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze this junk removal request: "${description}". 
    Provide an estimation of the load size, a category (Residential, Commercial, Construction, or Specialty), 
    a "Reclamation Score" from 1-100 (representing how much space is freed), 
    and a short, premium piece of advice on how to maintain the new space.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          estimatedVolume: { type: Type.STRING, description: "Small load, Half truck, Full truck, etc." },
          category: { type: Type.STRING },
          reclamationScore: { type: Type.NUMBER },
          aiAdvice: { type: Type.STRING }
        },
        required: ["estimatedVolume", "category", "reclamationScore", "aiAdvice"]
      }
    }
  });

  try {
    return JSON.parse(response.text.trim());
  } catch (error) {
    console.error("Failed to parse Gemini response:", error);
    throw new Error("Could not generate estimate.");
  }
}
