import React, { useState } from 'react';
import { getSmartEstimate } from '../services/geminiService';
import { QuoteResult } from '../types';

const SmartQuote: React.FC = () => {
  const [description, setDescription] = useState('');
  const [zipCode, setZipCode] = useState('');
  const [urgency, setUrgency] = useState('flexible');
  const [serviceType, setServiceType] = useState('residential');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<QuoteResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) return;

    setLoading(true);
    setError(null);
    try {
      const complexDescription = `
        Service Type: ${serviceType}
        Zip Code: ${zipCode}
        Urgency: ${urgency}
        Items: ${description}
      `;
      const estimate = await getSmartEstimate(complexDescription);
      setResult(estimate);
    } catch (err) {
      setError("We couldn't generate an estimate. Please try again or call our direct line.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section id="quote" className="py-24 bg-white">
      <div className="max-w-5xl mx-auto px-6">
        <div className="bg-brand-blue rounded-[48px] p-8 md:p-20 border border-brand-blue/20 shadow-[0_70px_140px_-30px_rgba(31,60,136,0.7)] text-white overflow-hidden relative">
          <div className="absolute top-0 right-0 w-64 h-64 bg-brand-orange/10 blur-[100px] -z-0"></div>
          
          <div className="text-center mb-12 relative z-10">
            <h2 className="text-4xl md:text-5xl font-black tracking-tight mb-4 font-heading uppercase">Smart Estimator</h2>
            <p className="text-brand-orange font-black uppercase tracking-[0.3em] text-xs">Powered by Gemini AI v3.0</p>
          </div>

          {!result ? (
            <form onSubmit={handleSubmit} className="space-y-8 relative z-10">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-3">
                  <label className="block text-[10px] font-black uppercase tracking-widest text-white/50">Service Type</label>
                  <select 
                    value={serviceType}
                    onChange={(e) => setServiceType(e.target.value)}
                    className="w-full px-6 py-4 rounded-2xl bg-white/5 border border-white/10 outline-none focus:border-brand-orange transition-all font-bold text-sm appearance-none shadow-xl"
                  >
                    <option value="residential" className="text-brand-blue">Residential Estate</option>
                    <option value="commercial" className="text-brand-blue">Commercial Office</option>
                    <option value="construction" className="text-brand-blue">Construction Site</option>
                  </select>
                </div>
                <div className="space-y-3">
                  <label className="block text-[10px] font-black uppercase tracking-widest text-white/50">Urgency</label>
                  <select 
                    value={urgency}
                    onChange={(e) => setUrgency(e.target.value)}
                    className="w-full px-6 py-4 rounded-2xl bg-white/5 border border-white/10 outline-none focus:border-brand-orange transition-all font-bold text-sm appearance-none shadow-xl"
                  >
                    <option value="immediate" className="text-brand-blue">Asap (Today/Tomorrow)</option>
                    <option value="week" className="text-brand-blue">Within 7 Days</option>
                    <option value="flexible" className="text-brand-blue">Flexible Timeline</option>
                  </select>
                </div>
                <div className="space-y-3">
                  <label className="block text-[10px] font-black uppercase tracking-widest text-white/50">Zip Code</label>
                  <input 
                    type="text"
                    value={zipCode}
                    onChange={(e) => setZipCode(e.target.value)}
                    placeholder="e.g. 90210"
                    className="w-full px-6 py-4 rounded-2xl bg-white/5 border border-white/10 outline-none focus:border-brand-orange transition-all font-bold text-sm placeholder:text-white/20 shadow-xl"
                  />
                </div>
              </div>

              <div className="space-y-4">
                <label className="block text-[10px] font-black uppercase tracking-widest text-white/50">Inventory Description</label>
                <textarea
                  className="w-full h-40 px-8 py-6 rounded-[32px] bg-white/5 border border-white/10 focus:ring-4 focus:ring-brand-orange/20 focus:border-brand-orange outline-none transition-all resize-none text-xl placeholder:text-white/20 shadow-xl"
                  placeholder="Tell us what needs to go..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  required
                />
              </div>
              <button
                type="submit"
                disabled={loading}
                className="w-full bg-brand-orange text-white py-6 rounded-full text-xl font-black hover:scale-105 active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-[0_45px_90px_-15px_rgba(255,138,0,0.8)] uppercase tracking-tight"
              >
                {loading ? 'Analyzing Volume...' : 'Calculate Estimate'}
              </button>
              {error && <p className="text-red-400 text-center font-bold text-sm">{error}</p>}
            </form>
          ) : (
            <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-700 relative z-10">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white/5 p-8 rounded-[32px] border border-white/10 backdrop-blur-sm shadow-2xl">
                  <p className="text-[10px] font-black text-white/40 uppercase tracking-[0.2em] mb-3">Load Volume</p>
                  <p className="text-2xl font-black text-brand-orange font-heading uppercase">{result.estimatedVolume}</p>
                </div>
                <div className="bg-white/5 p-8 rounded-[32px] border border-white/10 backdrop-blur-sm shadow-2xl">
                  <p className="text-[10px] font-black text-white/40 uppercase tracking-[0.2em] mb-3">Category</p>
                  <p className="text-2xl font-black font-heading uppercase">{result.category}</p>
                </div>
                <div className="bg-white/5 p-8 rounded-[32px] border border-white/10 backdrop-blur-sm shadow-2xl">
                  <p className="text-[10px] font-black text-white/40 uppercase tracking-[0.2em] mb-3">Impact Score</p>
                  <p className="text-2xl font-black text-brand-orange font-heading">{result.reclamationScore}%</p>
                </div>
              </div>
              <div className="bg-brand-orange/10 p-10 rounded-[40px] border border-brand-orange/20 shadow-[inset_0_2px_10px_rgba(0,0,0,0.2)]">
                <h4 className="font-black text-brand-orange uppercase tracking-widest text-[10px] mb-4">Gemini Space Optimization Advice</h4>
                <p className="text-xl text-white/90 leading-relaxed font-medium">"{result.aiAdvice}"</p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <button 
                  onClick={() => window.alert("Request sent. Our crew will call you within 15 minutes.")}
                  className="flex-1 bg-brand-orange text-white py-6 rounded-full font-black text-lg hover:bg-white hover:text-brand-blue transition-all shadow-[0_35px_70px_-10px_rgba(255,138,0,0.6)] uppercase tracking-tight"
                >
                  Confirm & Dispatch
                </button>
                <button 
                  onClick={() => {setResult(null); setDescription('');}}
                  className="px-10 py-6 text-white/40 font-bold hover:text-white transition-all uppercase text-[10px] tracking-widest"
                >
                  Start New Scan
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default SmartQuote;