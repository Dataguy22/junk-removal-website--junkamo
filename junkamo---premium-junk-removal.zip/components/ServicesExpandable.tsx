import React, { useState } from 'react';

interface ServiceDetail {
  id: string;
  title: string;
  outcome: string;
  description: string;
  items: string[];
  image: string;
}

const SERVICES: ServiceDetail[] = [
  {
    id: 'household',
    title: 'Home & Living Spaces',
    outcome: 'Household junk, Furniture, & Clutter',
    description: 'We handle the complete removal of household items that are in your way. From old sofa sets to attic clearouts, we lift it all so you don\'t have to.',
    items: ['Furniture & Mattresses', 'Appliances & Electronics', 'Attic, Basement & Garage Clutter'],
    image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=1200'
  },
  {
    id: 'specialty',
    title: 'Specialty & Yard',
    outcome: 'Appliances, Yard Waste, & More',
    description: 'Heavy appliances and outdoor waste require specialized handling. Our team is equipped with the right tools to clear your yard and remove bulky machinery safely.',
    items: ['Yard Waste & Debris', 'Large Appliances', 'Bulky Specialty Items'],
    image: 'https://images.unsplash.com/photo-1590674000551-367019c42637?auto=format&fit=crop&q=80&w=1200'
  },
  {
    id: 'commercial',
    title: 'Business & Construction',
    outcome: 'Office Cleanouts & Debris',
    description: 'Professional-grade removal for construction sites and commercial offices. We work around your schedule to ensure zero downtime for your business.',
    items: ['Construction Debris', 'Office Furniture', 'Commercial Waste'],
    image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=1200'
  }
];

const ServicesExpandable: React.FC = () => {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  return (
    <section id="services" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="mb-20">
          <span className="text-brand-orange font-black tracking-[0.3em] uppercase text-xs mb-4 block">What We Remove</span>
          <h2 className="text-4xl md:text-6xl font-black text-brand-blue tracking-tight font-heading leading-none uppercase">
            If it’s in your way, <br />
            <span className="text-brand-orange">we take it.</span>
          </h2>
        </div>

        <div className="space-y-6">
          {SERVICES.map((service) => (
            <div 
              key={service.id}
              className={`group border-2 transition-all duration-500 rounded-[40px] overflow-hidden ${
                expandedId === service.id 
                  ? 'border-brand-blue bg-brand-blue text-white shadow-[0_50px_120px_-25px_rgba(31,60,136,0.5)]' 
                  : 'border-gray-100 bg-gray-50 text-brand-blue hover:border-brand-orange/30 hover:shadow-[0_35px_70px_-20px_rgba(0,0,0,0.15)]'
              }`}
            >
              <button 
                onClick={() => setExpandedId(expandedId === service.id ? null : service.id)}
                className="w-full text-left p-8 md:p-12 flex flex-col md:flex-row md:items-center justify-between gap-6"
              >
                <div className="max-w-2xl">
                  <h3 className={`text-2xl md:text-4xl font-black font-heading mb-2 transition-colors ${
                    expandedId === service.id ? 'text-brand-orange' : 'text-brand-blue'
                  }`}>
                    {service.title}
                  </h3>
                  <p className={`text-lg md:text-xl font-medium ${
                    expandedId === service.id ? 'text-white/70' : 'text-gray-500'
                  }`}>
                    {service.outcome}
                  </p>
                </div>
                <div className="flex items-center gap-4">
                  <span className={`text-xs font-black uppercase tracking-widest px-6 py-2 rounded-full border-2 shadow-xl transition-all ${
                    expandedId === service.id ? 'border-brand-orange text-brand-orange bg-white/10' : 'border-brand-blue/10 text-brand-blue/40'
                  }`}>
                    {expandedId === service.id ? 'View Less' : 'Explore Category'}
                  </span>
                </div>
              </button>

              <div 
                className={`transition-all duration-700 ease-in-out overflow-hidden ${
                  expandedId === service.id ? 'max-h-[1000px] opacity-100' : 'max-h-0 opacity-0'
                }`}
              >
                <div className="p-8 md:p-12 pt-0 border-t border-white/10">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mt-8">
                    <div className="space-y-8">
                      <p className="text-xl leading-relaxed text-white/80 font-medium">
                        {service.description}
                      </p>
                      <div className="grid grid-cols-1 gap-4">
                        {service.items.map((item, i) => (
                          <div key={i} className="flex items-center gap-3">
                            <div className="w-6 h-6 rounded-full bg-brand-orange flex items-center justify-center flex-shrink-0 shadow-2xl shadow-brand-orange/40">
                              <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                              </svg>
                            </div>
                            <span className="font-bold text-sm tracking-tight">{item}</span>
                          </div>
                        ))}
                      </div>
                      <button 
                        onClick={() => document.getElementById('quote')?.scrollIntoView()}
                        className="bg-brand-orange text-white px-10 py-5 rounded-full font-black text-lg hover:scale-110 transition-all shadow-[0_30px_70px_-10px_rgba(255,138,0,0.7)] uppercase tracking-tight inline-block"
                      >
                        Get an Estimate
                      </button>
                    </div>
                    <div className="rounded-[32px] overflow-hidden h-80 lg:h-auto shadow-[0_45px_100px_-20px_rgba(0,0,0,0.5)] border-4 border-white/10">
                      <img 
                        src={service.image} 
                        alt={service.title} 
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesExpandable;