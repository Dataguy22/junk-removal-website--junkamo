import React from 'react';

const Trust: React.FC = () => {
  return (
    <section className="py-24 bg-white border-y border-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          <div className="flex-1 space-y-8">
            <h2 className="text-3xl md:text-4xl font-black text-brand-blue font-heading uppercase tracking-tight leading-none">
              Why You Can <br />
              <span className="text-brand-orange">Trust Junkamo.</span>
            </h2>
            <div className="space-y-6">
              <div className="flex gap-6 items-start">
                <div className="w-12 h-12 bg-gray-50 rounded-2xl flex items-center justify-center flex-shrink-0 text-brand-orange shadow-inner">
                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                  </svg>
                </div>
                <div>
                  <h4 className="font-black text-brand-blue text-lg mb-1 font-heading uppercase tracking-tight">Fully Insured Crew</h4>
                  <p className="text-gray-500 font-medium">Your property is protected with our comprehensive liability coverage.</p>
                </div>
              </div>
              <div className="flex gap-6 items-start">
                <div className="w-12 h-12 bg-gray-50 rounded-2xl flex items-center justify-center flex-shrink-0 text-brand-orange shadow-inner">
                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                  </svg>
                </div>
                <div>
                  <h4 className="font-black text-brand-blue text-lg mb-1 font-heading uppercase tracking-tight">Professional Team</h4>
                  <p className="text-gray-500 font-medium">Uniformed, background-checked, and highly trained experts.</p>
                </div>
              </div>
            </div>
          </div>
          <div className="flex-1 grid grid-cols-2 gap-4">
            <div className="bg-white p-8 rounded-[32px] text-center border border-gray-100 shadow-[0_20px_50px_-10px_rgba(0,0,0,0.1)]">
              <p className="text-3xl font-black text-brand-blue mb-1 font-heading">100%</p>
              <p className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Reliability</p>
            </div>
            <div className="bg-white p-8 rounded-[32px] text-center border border-gray-100 shadow-[0_20px_50px_-10px_rgba(0,0,0,0.1)]">
              <p className="text-3xl font-black text-brand-blue mb-1 font-heading">Clean</p>
              <p className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Modern Trucks</p>
            </div>
            <div className="bg-brand-blue p-8 rounded-[32px] text-center border border-brand-blue/10 col-span-2 shadow-[0_30px_70px_-15px_rgba(31,60,136,0.4)]">
              <p className="text-brand-orange font-bold text-sm mb-2 uppercase tracking-widest">Fast. Simple. Reliable.</p>
              <p className="text-white/60 text-xs font-medium italic leading-relaxed">Proper equipment for any scale of cleanup, from household to commercial.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Trust;