
import React from 'react';

const LogoBar: React.FC = () => {
  return (
    <section className="bg-white py-12 border-b border-gray-100 shadow-sm relative z-20">
      <div className="max-w-7xl mx-auto px-6">
        <p className="text-center text-[10px] font-black uppercase tracking-[0.3em] text-gray-300 mb-8">
          Trusted Partners in Asset Liquidation
        </p>
        <div className="flex flex-wrap justify-center lg:justify-between items-center gap-x-12 gap-y-8 grayscale opacity-40">
          <span className="font-black text-brand-blue tracking-tighter text-xl uppercase font-heading">Metro Realty</span>
          <span className="font-black text-brand-blue tracking-tighter text-xl uppercase font-heading">Zen Design</span>
          <span className="font-black text-brand-blue tracking-tighter text-xl uppercase font-heading">Prime Spaces</span>
          <span className="font-black text-brand-blue tracking-tighter text-xl uppercase font-heading">Urban Arch</span>
          <span className="hidden lg:inline font-black text-brand-blue tracking-tighter text-xl uppercase font-heading">Summit Logistics</span>
        </div>
      </div>
    </section>
  );
};

export default LogoBar;
