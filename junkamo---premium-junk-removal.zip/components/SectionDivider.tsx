
import React from 'react';

interface SectionDividerProps {
  label?: string;
  number?: string;
  light?: boolean;
}

const SectionDivider: React.FC<SectionDividerProps> = ({ label, number, light = false }) => {
  return (
    <div className={`relative w-full flex flex-col items-center justify-center py-12 ${light ? 'bg-white' : 'bg-[#FAFAFA]'}`}>
      <div className="w-full max-w-7xl px-6 flex items-center gap-4">
        {/* Left Line */}
        <div className="flex-1 h-[1px] bg-gray-200"></div>
        
        {/* Center Content */}
        <div className="flex flex-col items-center gap-3 px-4">
          {label && (
            <span className="text-[10px] font-black uppercase tracking-[0.5em] text-gray-400">
              {number && <span className="text-brand-orange mr-2">{number}</span>}
              {label}
            </span>
          )}
          <div className="w-16 h-1 bg-brand-orange rounded-full shadow-[0_4px_10px_rgba(255,138,0,0.3)]"></div>
        </div>
        
        {/* Right Line */}
        <div className="flex-1 h-[1px] bg-gray-200"></div>
      </div>
    </div>
  );
};

export default SectionDivider;
