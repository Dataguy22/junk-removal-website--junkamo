import React, { useEffect, useState } from 'react';

const REVIEWS = [
  {
    text: "Absolute precision in their execution. The team handled our multi-floor office cleanout with zero downtime.",
    author: "James Chen",
    role: "Small Business Owner",
    avatar: "https://i.pravatar.cc/150?u=james"
  },
  {
    text: "The only removal service I trust for my clients' high-end estates. Discretion and cleanliness are unmatched.",
    author: "Elena Rossi",
    role: "Estate Agent",
    avatar: "https://i.pravatar.cc/150?u=elena"
  },
  {
    text: "True experts. They categorized and donated 80% of our surplus, exactly as promised in their eco-manifesto.",
    author: "David Vogel",
    role: "Property Manager",
    avatar: "https://i.pravatar.cc/150?u=david"
  }
];

const SocialProof: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.1 }
    );

    const element = document.getElementById('social-proof-section');
    if (element) observer.observe(element);

    return () => observer.disconnect();
  }, []);

  return (
    <section id="social-proof-section" className="bg-white py-24 md:py-32 overflow-hidden relative">
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-brand-blue/5 blur-[120px] rounded-full pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-center mb-16 space-y-6">
          <h2 className={`text-4xl md:text-6xl font-black text-brand-blue tracking-tight font-heading leading-tight transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            Backed by Our Growing <br /> Community of <span className="text-brand-orange">Businesses</span>
          </h2>
          
          <p className={`text-lg md:text-xl text-gray-500 font-medium max-w-2xl mx-auto transition-all duration-700 delay-100 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            People choose Junkamo because we show up on time, work fast, and keep things simple.
          </p>

          <div className={`flex flex-col items-center gap-4 transition-all duration-700 delay-200 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <div className="flex -space-x-3">
              {[1, 2, 3, 4, 5].map((i) => (
                <img 
                  key={i} 
                  className="w-10 h-10 rounded-full border-2 border-white shadow-md" 
                  src={`https://i.pravatar.cc/100?img=${i + 10}`} 
                  alt="User" 
                />
              ))}
            </div>
            <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">
              Trusted by 5,000+ customers and growing.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {REVIEWS.map((review, idx) => (
            <div 
              key={idx} 
              style={{ transitionDelay: `${300 + (idx * 150)}ms` }}
              className={`p-10 bg-white rounded-[40px] border border-gray-100 flex flex-col justify-between shadow-[0_45px_90px_-20px_rgba(31,60,136,0.15)] hover:shadow-[0_60px_120px_-20px_rgba(31,60,136,0.3)] hover:-translate-y-3 transition-all duration-500 group relative ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'}`}
            >
              <div className="space-y-8">
                <div className="flex items-center gap-4">
                  <img 
                    src={review.avatar} 
                    alt={review.author} 
                    className="w-12 h-12 rounded-full grayscale group-hover:grayscale-0 transition-all border-2 border-brand-orange/20 shadow-lg"
                  />
                  <div>
                    <p className="font-black text-brand-blue text-sm uppercase tracking-tight">{review.author}</p>
                    <p className="text-[10px] font-bold text-brand-orange uppercase tracking-widest">@JunkamoVerified</p>
                  </div>
                </div>

                <p className="text-lg font-medium text-gray-600 leading-relaxed italic">
                  "{review.text}"
                </p>
              </div>

              <div className="mt-12 text-right">
                <p className="text-xs font-black text-gray-300 uppercase tracking-[0.2em]">
                  {review.role}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SocialProof;