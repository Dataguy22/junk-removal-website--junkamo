import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="relative min-h-[90vh] flex items-center pt-20 overflow-hidden bg-brand-blue">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1603796846097-bee99e4a601f?auto=format&fit=crop&q=80&w=1600" 
          alt="Junkamo expert providing professional service" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-white via-white/95 to-white/20 lg:to-transparent"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-white/40 via-transparent to-transparent"></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10 w-full py-20 lg:py-32">
        <div className="max-w-3xl">
          <div className="flex items-center gap-3 mb-8">
            <span className="inline-block px-4 py-1.5 text-[10px] font-black tracking-[0.2em] uppercase bg-brand-orange text-white rounded-full shadow-[0_15px_40px_-5px_rgba(255,138,0,0.6)]">
              Fast. Simple. Reliable.
            </span>
            <span className="text-brand-blue text-xs font-black tracking-widest uppercase opacity-70">
              The Junkamo Standard
            </span>
          </div>
          
          <h1 className="text-4xl md:text-6xl xl:text-7xl font-black tracking-tight text-brand-blue leading-[1.1] mb-10 font-heading drop-shadow-sm uppercase">
            Fast, Reliable Junk Removal — <br />
            <span className="text-brand-orange">Done in Minutes, Not Hours.</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-700 mb-12 leading-relaxed max-w-xl font-medium">
            We handle the mess so you can get back to what matters.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-5 mb-16">
            <a 
              href="#quote" 
              className="bg-brand-orange text-white px-10 py-5 rounded-full text-lg font-black hover:bg-brand-blue hover:scale-105 transition-all shadow-[0_45px_90px_-15px_rgba(255,138,0,0.8)] text-center uppercase tracking-tight"
            >
              Book in Minutes
            </a>
            <a 
              href="#process" 
              className="bg-white/80 backdrop-blur-sm text-brand-blue border-2 border-brand-blue/10 px-10 py-5 rounded-full text-lg font-bold hover:bg-white hover:border-brand-blue hover:scale-105 transition-all text-center shadow-[0_25px_50px_-10px_rgba(31,60,136,0.3)]"
            >
              How It Works
            </a>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 pt-12 border-t border-brand-blue/10">
            <div>
              <p className="text-3xl font-black text-brand-blue">Same-Day</p>
              <p className="text-xs text-gray-500 font-bold uppercase tracking-widest mt-1">Availability</p>
            </div>
            <div>
              <p className="text-3xl font-black text-brand-blue">Zero</p>
              <p className="text-xs text-gray-500 font-bold uppercase tracking-widest mt-1">Effort Required</p>
            </div>
            <div>
              <p className="text-3xl font-black text-brand-blue">Upfront</p>
              <p className="text-xs text-gray-500 font-bold uppercase tracking-widest mt-1">Clear Pricing</p>
            </div>
            <div>
              <p className="text-3xl font-black text-brand-blue">#1</p>
              <p className="text-xs text-gray-500 font-bold uppercase tracking-widest mt-1">Trusted Team</p>
            </div>
          </div>
        </div>
      </div>

      <div className="hidden xl:flex absolute bottom-12 right-12 z-20 items-center gap-4 bg-white/90 backdrop-blur-md p-6 rounded-[32px] border border-white shadow-[0_55px_110px_-15px_rgba(31,60,136,0.45)]">
        <div className="w-12 h-12 bg-brand-orange rounded-2xl flex items-center justify-center text-white shadow-2xl shadow-brand-orange/40">
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <div>
          <p className="text-brand-blue font-black uppercase text-sm tracking-tight">Verified Expert Team</p>
          <p className="text-gray-500 text-[10px] font-black uppercase tracking-widest">Background checked & insured</p>
        </div>
      </div>
    </section>
  );
};

export default Hero;