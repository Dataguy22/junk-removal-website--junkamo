import React from 'react';

const CTASoft: React.FC = () => {
  return (
    <section className="py-24 bg-[#FAFAFA] border-y border-gray-100">
      <div className="max-w-4xl mx-auto px-6 text-center">
        <h2 className="text-2xl md:text-3xl font-black text-brand-blue font-heading uppercase tracking-tight mb-6">Not ready for a full cleanout?</h2>
        <p className="text-gray-500 mb-10 text-lg font-medium leading-relaxed">
          Save our contact information or download our <span className="text-brand-orange font-bold">"Space Planning Guide"</span> to start organizing on your own terms. We're here when you need us.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
          <button className="text-brand-blue font-black uppercase text-sm tracking-widest border-b-2 border-brand-blue pb-1 hover:text-brand-orange hover:border-brand-orange transition-all">
            Download Guide
          </button>
          <span className="text-gray-300 hidden sm:inline">|</span>
          <button className="text-brand-blue font-black uppercase text-sm tracking-widest border-b-2 border-brand-blue pb-1 hover:text-brand-orange hover:border-brand-orange transition-all">
            Call for Advice
          </button>
        </div>
      </div>
    </section>
  );
};

export default CTASoft;