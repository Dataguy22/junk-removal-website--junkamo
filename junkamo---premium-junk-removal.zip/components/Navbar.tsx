
import React from 'react';

const Navbar: React.FC = () => {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md border-b-2 border-gray-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        <div className="text-2xl font-black tracking-tighter text-brand-blue font-heading uppercase">
          JUNKA<span className="text-brand-orange">MO</span>
        </div>
        <div className="hidden md:flex gap-8 text-[10px] font-black uppercase tracking-widest text-gray-400">
          <a href="#services" className="hover:text-brand-orange transition-colors">Services</a>
          <a href="#benefits" className="hover:text-brand-orange transition-colors">Why Us</a>
          <a href="#process" className="hover:text-brand-orange transition-colors">Process</a>
          <a href="#quote" className="hover:text-brand-orange transition-colors">Estimator</a>
        </div>
        <a 
          href="#quote" 
          className="bg-brand-orange text-white px-8 py-3 text-xs font-black rounded-full hover:bg-brand-blue hover:scale-105 transition-all duration-300 shadow-[0_15px_35px_-5px_rgba(255,138,0,0.5)] uppercase tracking-widest"
        >
          Get Quote
        </a>
      </div>
    </nav>
  );
};

export default Navbar;
