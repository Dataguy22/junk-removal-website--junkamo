import React, { useState } from 'react';

const BENEFITS = [
  {
    id: 'fast',
    title: 'Fast Pickup',
    label: 'Same-Day',
    description: 'Same-day or next-day availability for your immediate removal needs. We respect your schedule.',
    image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=800',
    stats: { label: 'Response Time', value: '< 2 hrs' },
    color: 'bg-brand-orange'
  },
  {
    id: 'pricing',
    title: 'Upfront Pricing',
    label: 'Transparent',
    description: 'Clear rates with zero surprises. You only pay for the volume we haul. No hidden fees.',
    image: 'https://images.unsplash.com/photo-1620641788421-7a1c342ea42e?auto=format&fit=crop&q=80&w=800',
    stats: { label: 'Accuracy', value: '100%' },
    color: 'bg-brand-blue'
  },
  {
    id: 'effort',
    title: 'Zero Effort',
    label: 'Full Service',
    description: 'We handle all lifting, loading, sorting, and disposal. You don\'t move a single thing.',
    image: 'https://images.unsplash.com/photo-1614850523296-d8c1af93d400?auto=format&fit=crop&q=80&w=800',
    stats: { label: 'Manual Labor', value: '0%' },
    color: 'bg-brand-blue'
  },
  {
    id: 'eco',
    title: 'Eco-Friendly',
    label: 'Sustainable',
    description: 'Donations and responsible disposal are prioritized. Keeping your junk out of landfills.',
    image: 'https://images.unsplash.com/photo-1627163439134-7a8c47ee8020?auto=format&fit=crop&q=80&w=800',
    stats: { label: 'Recycled', value: '92%' },
    color: 'bg-brand-orange'
  }
];

const Benefits: React.FC = () => {
  const [expandedId, setExpandedId] = useState<string>('effort');

  return (
    <section id="benefits" className="py-24 bg-white overflow-visible">
      <div className="max-w-7xl mx-auto px-6">
        <div className="mb-12 text-left">
          <h2 className="text-4xl md:text-5xl font-black font-heading uppercase tracking-tighter text-brand-blue leading-none">
            Why Busy Customers <br />
            <span className="text-brand-orange">Choose Junkamo</span>
          </h2>
        </div>

        {/* Mobile View: Vertical Stacked Accordion */}
        <div className="lg:hidden flex flex-col gap-4">
          {BENEFITS.map((benefit) => {
            const isExpanded = expandedId === benefit.id;
            return (
              <div
                key={benefit.id}
                onClick={() => setExpandedId(benefit.id)}
                className={`relative overflow-hidden rounded-[32px] transition-all duration-500 border border-gray-100 ${
                  isExpanded ? 'h-[400px] shadow-[0_45px_90px_-20px_rgba(31,60,136,0.35)]' : 'h-24 shadow-md'
                }`}
              >
                <img
                  src={benefit.image}
                  className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-700 ${isExpanded ? 'opacity-100' : 'opacity-20'}`}
                  alt={benefit.title}
                />
                <div className={`absolute inset-0 ${isExpanded ? benefit.color + '/90' : 'bg-white/95'}`} />
                
                <div className="relative h-full p-6 flex flex-col justify-between">
                  <div className="flex justify-between items-center">
                    <h3 className={`font-black uppercase tracking-tight ${isExpanded ? 'text-white text-2xl' : 'text-brand-blue text-lg'}`}>
                      {benefit.title}
                    </h3>
                    {!isExpanded && (
                      <div className="bg-brand-orange/10 p-2 rounded-full shadow-lg">
                        <svg className="w-4 h-4 text-brand-orange" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M19 9l-7 7-7-7" />
                        </svg>
                      </div>
                    )}
                  </div>
                  
                  {isExpanded && (
                    <div className="space-y-6">
                      <p className="text-white text-sm font-bold leading-relaxed">
                        {benefit.description}
                      </p>
                      <div className="flex gap-4">
                        <div className="bg-white/20 backdrop-blur-xl p-4 rounded-2xl border border-white/20 flex-1 shadow-2xl">
                          <p className="text-[8px] font-black text-white/60 uppercase tracking-widest mb-1">{benefit.stats.label}</p>
                          <p className="text-xl font-black text-white">{benefit.stats.value}</p>
                        </div>
                        <div className="bg-white p-4 rounded-2xl flex items-center justify-center shadow-2xl">
                          <svg className={`w-6 h-6 ${benefit.color === 'bg-brand-orange' ? 'text-brand-orange' : 'text-brand-blue'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                          </svg>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Desktop View: Multi-Width Card Slider */}
        <div className="hidden lg:flex flex-row gap-6 h-[600px] w-full">
          {BENEFITS.map((benefit) => {
            const isExpanded = expandedId === benefit.id;
            return (
              <div
                key={benefit.id}
                onClick={() => setExpandedId(benefit.id)}
                className={`relative cursor-pointer overflow-hidden rounded-[48px] transition-all duration-700 ease-[cubic-bezier(0.25,1,0.5,1)] ${
                  isExpanded 
                    ? 'flex-[5] shadow-[0_60px_120px_-30px_rgba(31,60,136,0.5)] z-20 scale-100' 
                    : 'flex-1 hover:bg-gray-50 z-10'
                }`}
              >
                <div className="absolute inset-0">
                  <img
                    src={benefit.image}
                    alt={benefit.title}
                    className={`w-full h-full object-cover transition-transform duration-1000 ${isExpanded ? 'scale-105' : 'scale-125 grayscale opacity-20'}`}
                  />
                  <div className={`absolute inset-0 transition-opacity duration-700 ${isExpanded ? benefit.color + '/90' : 'bg-white/90'}`} />
                </div>

                <div className={`absolute inset-0 flex items-center justify-center transition-opacity duration-500 ${isExpanded ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}>
                  <span className="text-2xl font-black font-heading text-brand-blue rotate-180 [writing-mode:vertical-lr] uppercase tracking-[0.2em] whitespace-nowrap">
                    {benefit.label}
                  </span>
                </div>

                <div className={`absolute inset-0 p-12 flex flex-col justify-between transition-all duration-700 ${isExpanded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10 pointer-events-none'}`}>
                  <div>
                    <span className="px-4 py-1 bg-white text-brand-blue text-[10px] font-black uppercase tracking-widest rounded-full shadow-2xl">
                       Elite Standard
                    </span>
                    <h3 className="text-5xl font-black text-white font-heading uppercase tracking-tight mt-6 mb-4">
                      {benefit.title}
                    </h3>
                    <p className="text-white text-xl font-bold leading-relaxed max-w-sm">
                      {benefit.description}
                    </p>
                  </div>

                  <div className="flex gap-4">
                    <div className="bg-white/20 backdrop-blur-2xl p-6 rounded-[32px] border border-white/20 flex-1 shadow-2xl">
                      <p className="text-[10px] font-black text-white/60 uppercase tracking-widest mb-1">{benefit.stats.label}</p>
                      <p className="text-3xl font-black text-white">{benefit.stats.value}</p>
                    </div>
                    <div className="bg-white p-6 rounded-[32px] flex items-center justify-center shadow-[0_30px_60px_-10px_rgba(0,0,0,0.4)]">
                       <div className={`w-12 h-12 ${benefit.color} rounded-full flex items-center justify-center shadow-lg`}>
                          <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                          </svg>
                       </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Benefits;