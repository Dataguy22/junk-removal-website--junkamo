import React from 'react';

const STEPS = [
  {
    id: '01',
    title: 'Tell Us Your Needs',
    description: 'Describe what you need removed or use our AI estimator tool for an instant scan.'
  },
  {
    id: '02',
    title: 'Get Upfront Price',
    description: 'We provide a clear, transparent rate based on volume. No hidden surprises.'
  },
  {
    id: '03',
    title: 'We Get to Work',
    description: 'Our team arrives on time, handles all the lifting, and loads everything up.'
  },
  {
    id: '04',
    title: 'Enjoy Your Space',
    description: 'We haul it away and sweep up. Your space is clear, clean, and reclaimed.'
  }
];

const Process: React.FC = () => {
  return (
    <section id="process" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-24">
          <h2 className="text-4xl md:text-6xl font-black text-brand-blue tracking-tight mb-6 font-heading uppercase">Simple. Fast. Done.</h2>
          <p className="text-gray-400 max-w-xl mx-auto text-lg font-medium italic">From clutter to clarity in 4 easy steps.</p>
        </div>

        <div className="flex flex-col md:flex-row items-start justify-between gap-12 relative">
          <div className="hidden md:block absolute top-12 left-0 w-full h-0.5 bg-gray-200 -z-0"></div>
          
          {STEPS.map((step) => (
            <div key={step.id} className="relative flex-1 z-10 bg-white pr-8 group">
              <div className="w-16 h-16 bg-brand-blue rounded-[20px] flex items-center justify-center font-black text-white text-2xl mb-8 shadow-[0_35px_70px_-10px_rgba(31,60,136,0.5)] group-hover:scale-110 transition-transform duration-500">
                {step.id}
              </div>
              <h3 className="text-xl font-black text-brand-blue mb-4 font-heading uppercase tracking-tight">{step.title}</h3>
              <p className="text-gray-500 leading-relaxed font-medium text-sm">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Process;