import React from 'react';

const CTAStrong: React.FC = () => {
  return (
    <section className="py-32 bg-brand-orange text-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-12">
          <div className="max-w-2xl text-center lg:text-left">
            <h2 className="text-5xl md:text-7xl font-black font-heading leading-none uppercase tracking-tighter mb-6">
              READY TO CLEAR <br />
              <span className="text-brand-blue">YOUR SPACE?</span>
            </h2>
            <p className="text-white/80 text-xl font-bold uppercase tracking-widest">Book in minutes. We handle the rest.</p>
          </div>
          <div className="flex flex-col gap-4 w-full max-w-sm">
            <button 
              onClick={() => document.getElementById('quote')?.scrollIntoView()}
              className="bg-brand-blue text-white px-12 py-7 rounded-[40px] text-2xl font-black hover:scale-105 transition-all shadow-[0_50px_100px_-15px_rgba(31,60,136,0.6)] uppercase tracking-tighter"
            >
              Get Started Now
            </button>
            <p className="text-center text-sm font-bold opacity-60 italic">Your space, cleared on your schedule.</p>
          </div>
        </div>
      </div>
      {/* Dynamic Background */}
      <div className="absolute top-0 left-0 w-full h-full opacity-10">
        <div className="absolute top-10 left-10 w-40 h-40 border-[20px] border-white rounded-full"></div>
        <div className="absolute bottom-10 right-10 w-80 h-80 border-[40px] border-white rounded-full"></div>
      </div>
    </section>
  );
};

export default CTAStrong;