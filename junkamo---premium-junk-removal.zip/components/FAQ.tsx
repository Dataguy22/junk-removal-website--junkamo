import React, { useState } from 'react';

const FAQS = [
  {
    q: "How fast can you come?",
    a: "Most pickups are same-day or next-day. We work with your schedule to ensure minimal waiting."
  },
  {
    q: "Do I need to move anything beforehand?",
    a: "No. We handle all lifting and loading. Whether it's in the basement or the attic, just point to it and we take it."
  },
  {
    q: "How do you price jobs?",
    a: "Our pricing is based on volume—you only pay for what we haul. This ensures you get a fair price for every job."
  },
  {
    q: "Do you recycle or donate items?",
    a: "Yes. We prioritize eco-friendly disposal, partnering with local organizations to donate or recycle whenever possible."
  },
  {
    q: "Can you remove heavy items?",
    a: "Absolutely. Our team is fully equipped and trained for large, bulky items like appliances and heavy furniture."
  }
];

const FAQ: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section className="py-24 bg-white">
      <div className="max-w-4xl mx-auto px-6">
        <div className="mb-16 text-center">
          <h2 className="text-4xl font-black text-brand-blue font-heading uppercase tracking-tight mb-4">Questions? We Have Answers.</h2>
          <p className="text-brand-orange font-bold uppercase tracking-widest text-xs">Fast. Simple. Reliable.</p>
        </div>

        <div className="space-y-4">
          {FAQS.map((faq, i) => (
            <div key={i} className="border-2 border-gray-50 rounded-[32px] overflow-hidden shadow-sm hover:shadow-md transition-shadow">
              <button 
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
                className="w-full text-left p-8 flex items-center justify-between hover:bg-gray-50 transition-colors"
              >
                <span className="text-xl font-black text-brand-blue font-heading uppercase tracking-tight">{faq.q}</span>
                <span className={`text-2xl font-black text-brand-orange transition-transform duration-300 ${openIndex === i ? 'rotate-45' : ''}`}>+</span>
              </button>
              <div className={`transition-all duration-300 ease-in-out overflow-hidden ${openIndex === i ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'}`}>
                <div className="p-8 pt-0 text-gray-500 font-medium text-lg leading-relaxed">
                  {faq.a}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;