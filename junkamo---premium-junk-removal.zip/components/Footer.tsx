import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-brand-blue text-white pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-start gap-16 mb-20">
          <div className="max-w-sm">
            <div className="text-3xl font-black tracking-tighter text-white mb-6 font-heading uppercase">
              JUNKA<span className="text-brand-orange">MO</span>
            </div>
            <p className="text-white/50 leading-relaxed text-lg font-medium italic">
              Fast. Simple. Reliable.<br />
              Your space, cleared on your schedule.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-16 text-sm">
            <div>
              <h5 className="font-black mb-8 text-white/30 uppercase tracking-[0.2em] text-xs">Junkamo</h5>
              <ul className="space-y-5 text-white/70 font-bold">
                <li><a href="#services" className="hover:text-brand-orange transition-colors">What We Remove</a></li>
                <li><a href="#benefits" className="hover:text-brand-orange transition-colors">Why Busy People Love Us</a></li>
                <li><a href="#process" className="hover:text-brand-orange transition-colors">How It Works</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-black mb-8 text-white/30 uppercase tracking-[0.2em] text-xs">Company</h5>
              <ul className="space-y-5 text-white/70 font-bold">
                <li><a href="#" className="hover:text-brand-orange transition-colors">Privacy</a></li>
                <li><a href="#" className="hover:text-brand-orange transition-colors">Terms</a></li>
                <li><a href="#" className="hover:text-brand-orange transition-colors">Direct Support</a></li>
              </ul>
            </div>
            <div className="col-span-2 md:col-span-1">
              <h5 className="font-black mb-8 text-white/30 uppercase tracking-[0.2em] text-xs">Coverage</h5>
              <p className="text-white/70 font-bold leading-relaxed">
                Metro Service Area<br />
                Regional Logistics Center<br />
                Available 24/7 for Quote
              </p>
            </div>
          </div>
        </div>
        <div className="flex flex-col md:flex-row justify-between items-center pt-12 border-t border-white/5 text-[10px] font-black uppercase tracking-[0.2em] text-white/20">
          <p>© 2024 JUNKAMO. Reclaiming spaces since 2009.</p>
          <div className="flex gap-12 mt-6 md:mt-0">
            <span className="hover:text-white cursor-pointer transition-colors shadow-blue-500/10">Fast</span>
            <span className="hover:text-white cursor-pointer transition-colors">Simple</span>
            <span className="hover:text-white cursor-pointer transition-colors">Reliable</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;