import React from 'react';

const REVIEWS = [
  {
    name: "Marcus Thorne",
    service: "Full Office Cleanout",
    text: "Minimal disruption, maximum efficiency. Junkamo cleared two floors over the weekend. Professionalism was 10/10.",
    rating: 5
  },
  {
    name: "Sarah Lindt",
    service: "Estate Restoration",
    text: "They treated my late mother's items with such respect. Most were donated as requested. Truly a white-glove service.",
    rating: 5
  },
  {
    name: "Kevin Wu",
    service: "Residential Refresh",
    text: "The AI quote was spot on. Team showed up exactly when promised and swept up after. Highly recommend.",
    rating: 5
  },
  {
    name: "Elena G.",
    service: "Construction Debris",
    text: "Our building site was a mess. Junkamo came in and made it safe again in just 4 hours. Absolute experts.",
    rating: 5
  }
];

const TestimonialsCards: React.FC = () => {
  return (
    <section className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="mb-16">
          <h2 className="text-3xl md:text-5xl font-black text-brand-blue font-heading uppercase tracking-tight">Real Results <br/><span className="text-brand-orange">Real Words.</span></h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {REVIEWS.map((review, i) => (
            <div key={i} className="p-8 bg-gray-50 rounded-[32px] border border-gray-100 hover:border-brand-orange/30 shadow-[0_35px_70px_-15px_rgba(0,0,0,0.1)] hover:shadow-[0_50px_100px_-20px_rgba(31,60,136,0.25)] transition-all duration-500">
              <div className="flex text-brand-orange mb-6">
                {[...Array(5)].map((_, j) => (
                  <svg key={j} className="w-3 h-3 fill-current" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
              <p className="text-gray-600 font-medium italic mb-8 leading-relaxed">"{review.text}"</p>
              <div>
                <p className="font-black text-brand-blue text-sm uppercase tracking-tight">{review.name}</p>
                <p className="text-[10px] font-bold text-brand-orange uppercase tracking-[0.2em]">{review.service}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsCards;