
import React from 'react';
import { ServiceItem } from '../types';

const SERVICES: ServiceItem[] = [
  {
    id: 'res',
    title: 'Residential Estates',
    description: 'Bespoke cleaning and removal for homeowners seeking a minimalist, high-end lifestyle.',
    image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'com',
    title: 'Commercial Assets',
    description: 'Seamless office cleanouts designed to minimize disruption and maximize productivity.',
    image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'eco',
    title: 'Eco-Forward Disposal',
    description: 'We prioritize donation and recycling, ensuring 90% of items stay out of landfills.',
    image: 'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?auto=format&fit=crop&q=80&w=800'
  }
];

const Services: React.FC = () => {
  return (
    <section id="services" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="mb-16">
          <span className="text-brand-green font-black tracking-widest uppercase text-xs mb-4 block">What we do</span>
          <h2 className="text-4xl md:text-5xl font-black text-brand-blue tracking-tight mb-4 font-heading">Professional Expertise.</h2>
          <div className="w-20 h-2 bg-brand-orange rounded-full"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {SERVICES.map((service) => (
            <div key={service.id} className="group cursor-default">
              <div className="overflow-hidden rounded-3xl mb-8 aspect-[4/3] shadow-xl shadow-gray-100">
                <img 
                  src={service.image} 
                  alt={service.title} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000"
                />
              </div>
              <h3 className="text-2xl font-black text-brand-blue mb-4 font-heading">{service.title}</h3>
              <p className="text-gray-500 leading-relaxed text-lg font-medium">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
